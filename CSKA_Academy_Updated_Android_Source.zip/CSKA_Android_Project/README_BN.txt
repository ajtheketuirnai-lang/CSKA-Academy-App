CSKA Academy Android Project

এই প্রজেক্টটি Android WebView wrapper। এতে CSKA অফলাইন ড্যাশবোর্ড, লোগো এবং Android backup/restore picker যুক্ত আছে।

বিল্ড: GitHub Actions workflow-এ Gradle 8.9 ইনস্টল করে `gradle --no-daemon assembleDebug` চালাতে হবে। এই কারণে Gradle Wrapper (`gradlew`) ফাইল আলাদা করে দরকার হবে না।

প্রয়োজন: JDK 17, Android SDK Platform 35 এবং Build Tools 35.0.0।

গুরুত্বপূর্ণ:
- Google Drive-এ ব্যাকআপ Save/Open picker দিয়ে ম্যানুয়ালি করা যায়; এটি automatic background sync নয়।
- পুরোনো অ্যাপের localStorage নতুন APK-তে নিজে থেকে স্থানান্তরিত হবে না। JSON backup নিয়ে নতুন অ্যাপে Restore করতে হবে।
- এই ZIP source project; এটি নিজে APK নয়।
