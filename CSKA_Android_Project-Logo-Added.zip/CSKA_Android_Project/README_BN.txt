CSKA Academy Android Project

এই প্রজেক্টে Android WebView wrapper এবং Android Storage Access Framework (SAF) যুক্ত করা হয়েছে।
ব্যাকআপ সংরক্ষণে Android-এর Save As picker খুলবে। সেখানে Google Drive provider দেখালে Drive-এ ফোল্ডার বেছে Save করা যাবে।
পুনরুদ্ধারে Open picker খুলবে; Google Drive থেকে JSON ব্যাকআপ বেছে নেওয়া যাবে।

গুরুত্বপূর্ণ:
- এটি স্বয়ংক্রিয় ব্যাকগ্রাউন্ড Google Drive Sync নয়।
- Drive picker-এ Google Drive দেখা যাবে কি না তা ফোনে Drive অ্যাপ/প্রোভাইডার সক্রিয় থাকার ওপর নির্ভর করে।
- APK এখানে বিল্ড করা হয়নি; এটি Android Studio-তে খোলার source project।
- বিল্ডের জন্য Android Studio, JDK 17 এবং Android SDK Platform 35 দরকার।
- Android Studio-তে ফোল্ডারটি Open করে Gradle Sync, তারপর Build > Build APK(s)।
- পুরোনো অ্যাপের localStorage এই নতুন package-এ স্বয়ংক্রিয়ভাবে আসবে না। আগে রাখা JSON ব্যাকআপটি নতুন অ্যাপে Restore করতে হবে।
