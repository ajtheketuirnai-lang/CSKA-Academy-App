package com.cska.academy

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import java.io.IOException

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var pendingBackup: String? = null
    private var pendingName: String = "cska-backup.json"
    private val createBackupRequest = 4101
    private val openBackupRequest = 4102

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = true
        web.settings.allowContentAccess = true
        web.webViewClient = WebViewClient()
        web.webChromeClient = WebChromeClient()
        web.addJavascriptInterface(CSKABridge(), "CSKABridge")
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
    }

    inner class CSKABridge {
        @JavascriptInterface
        fun saveBackup(data: String, filename: String) {
            runOnUiThread {
                pendingBackup = data
                pendingName = filename.replace(Regex("[^A-Za-z0-9._-]"), "_")
                val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "application/json"
                    putExtra(Intent.EXTRA_TITLE, pendingName)
                }
                startActivityForResult(intent, createBackupRequest)
            }
        }

        @JavascriptInterface
        fun openBackup() {
            runOnUiThread {
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "application/json"
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                startActivityForResult(intent, openBackupRequest)
            }
        }
    }

    @Deprecated("Legacy result callback is used for broad Android compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data?.data == null) {
            pendingBackup = null
            return
        }
        val uri: Uri = data.data!!
        when (requestCode) {
            createBackupRequest -> {
                try {
                    contentResolver.openOutputStream(uri)?.use { stream ->
                        stream.write((pendingBackup ?: "").toByteArray(Charsets.UTF_8))
                    } ?: throw IOException("Unable to open destination")
                    Toast.makeText(this, "ব্যাকআপ সংরক্ষণ হয়েছে", Toast.LENGTH_LONG).show()
                } catch (e: Exception) {
                    Toast.makeText(this, "ব্যাকআপ সংরক্ষণ করা যায়নি", Toast.LENGTH_LONG).show()
                } finally {
                    pendingBackup = null
                }
            }
            openBackupRequest -> {
                try {
                    val raw = contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
                        ?: throw IOException("Unable to read backup")
                    val quoted = org.json.JSONObject.quote(raw)
                    web.evaluateJavascript("window.onNativeBackupLoaded && window.onNativeBackupLoaded($quoted);", null)
                } catch (e: Exception) {
                    Toast.makeText(this, "ব্যাকআপ ফাইল পড়া যায়নি", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    override fun onBackPressed() {
        if (::web.isInitialized && web.canGoBack()) web.goBack() else super.onBackPressed()
    }
}
